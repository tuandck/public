<?php
/**
 * Youtube Content System.
 *
 * @package BHDT_Core_System
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Zenclau_V1_Content_Model' ) ) {
	/**
	 * Database model/repository for Youtube Content System.
	 */
	final class Zenclau_V1_Content_Model {
		/**
		 * Products table name.
		 *
		 * @return string
		 */
		public static function products_table() {
			global $wpdb;

			return $wpdb->prefix . 'zenclau_v1_products';
		}

		/**
		 * Posts queue table name.
		 *
		 * @return string
		 */
		public static function posts_queue_table() {
			global $wpdb;

			return $wpdb->prefix . 'zenclau_v1_posts_queue';
		}

		/**
		 * Trusted channels table name.
		 *
		 * @return string
		 */
		public static function trusted_channels_table() {
			global $wpdb;

			return $wpdb->prefix . 'zenclau_v1_trusted_channels';
		}

		/**
		 * Create/upgrade V1 tables.
		 *
		 * @return void
		 */
		public static function install_tables() {
			global $wpdb;

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			$charset_collate = $wpdb->get_charset_collate();
			$products        = self::products_table();
			$posts_queue     = self::posts_queue_table();
			$channels        = self::trusted_channels_table();

			dbDelta(
				"CREATE TABLE {$products} (
					id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
					name VARCHAR(255) NOT NULL,
					official_url TEXT NOT NULL,
					search_keywords TEXT NOT NULL,
					created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
					PRIMARY KEY  (id)
				) {$charset_collate};"
			);

			dbDelta(
				"CREATE TABLE {$posts_queue} (
					id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
					product_id BIGINT(20) UNSIGNED NOT NULL,
					youtube_url VARCHAR(255) DEFAULT NULL,
					content_json LONGTEXT NOT NULL,
					status VARCHAR(50) NOT NULL DEFAULT 'pending',
					created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
					PRIMARY KEY  (id),
					KEY product_id (product_id),
					KEY status (status)
				) {$charset_collate};"
			);

			dbDelta(
				"CREATE TABLE {$channels} (
					id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
					channel_name VARCHAR(255) NOT NULL,
					youtube_channel_id VARCHAR(100) NOT NULL,
					is_active TINYINT(1) NOT NULL DEFAULT 1,
					PRIMARY KEY  (id),
					UNIQUE KEY youtube_channel_id (youtube_channel_id)
				) {$charset_collate};"
			);
		}

		/**
		 * Ensure tables exist during normal admin/REST usage.
		 *
		 * @return void
		 */
		public static function maybe_install_tables() {
			$installed_version = get_option( 'zenclau_v1_content_db_version', '' );
			if ( '1.0.0' === $installed_version ) {
				return;
			}

			self::install_tables();
			update_option( 'zenclau_v1_content_db_version', '1.0.0', false );
		}

		/**
		 * Format product row.
		 *
		 * @param object|array $row Raw row.
		 * @return array
		 */
		private static function format_product( $row ) {
			$row = (array) $row;

			return array(
				'id'              => absint( $row['id'] ?? 0 ),
				'name'            => (string) ( $row['name'] ?? '' ),
				'official_url'    => (string) ( $row['official_url'] ?? '' ),
				'search_keywords' => (string) ( $row['search_keywords'] ?? '' ),
				'created_at'      => (string) ( $row['created_at'] ?? '' ),
			);
		}

		/**
		 * Format queue row.
		 *
		 * @param object|array $row Raw row.
		 * @return array
		 */
		private static function format_queue_item( $row ) {
			$row          = (array) $row;
			$content_json = json_decode( (string) ( $row['content_json'] ?? '{}' ), true );
			if ( ! is_array( $content_json ) ) {
				$content_json = array();
			}

			return array(
				'id'           => absint( $row['id'] ?? 0 ),
				'product_id'   => absint( $row['product_id'] ?? 0 ),
				'youtube_url'  => (string) ( $row['youtube_url'] ?? '' ),
				'content_json' => $content_json,
				'status'       => (string) ( $row['status'] ?? 'pending' ),
				'created_at'   => (string) ( $row['created_at'] ?? '' ),
			);
		}

		/**
		 * Get all products.
		 *
		 * @return array
		 */
		public static function get_products() {
			global $wpdb;

			self::maybe_install_tables();

			$rows = $wpdb->get_results( "SELECT * FROM " . self::products_table() . ' ORDER BY id DESC' );

			return array_map( array( __CLASS__, 'format_product' ), (array) $rows );
		}

		/**
		 * Get one product.
		 *
		 * @param int $id Product id.
		 * @return array|null
		 */
		public static function get_product( $id ) {
			global $wpdb;

			self::maybe_install_tables();

			$row = $wpdb->get_row(
				$wpdb->prepare( 'SELECT * FROM ' . self::products_table() . ' WHERE id = %d', absint( $id ) )
			);

			return $row ? self::format_product( $row ) : null;
		}

		/**
		 * Create product.
		 *
		 * @param array $data Product payload.
		 * @return array|WP_Error
		 */
		public static function create_product( array $data ) {
			global $wpdb;

			self::maybe_install_tables();

			$name            = sanitize_text_field( $data['name'] ?? '' );
			$official_url    = esc_url_raw( $data['official_url'] ?? '' );
			$search_keywords = sanitize_textarea_field( $data['search_keywords'] ?? '' );

			if ( '' === $name || '' === $search_keywords ) {
				return new WP_Error( 'zenclau_v1_product_missing_fields', __( 'V1: Product requires name and search_keywords.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$inserted = $wpdb->insert(
				self::products_table(),
				array(
					'name'            => $name,
					'official_url'    => $official_url,
					'search_keywords' => $search_keywords,
				),
				array( '%s', '%s', '%s' )
			);

			if ( false === $inserted ) {
				return new WP_Error( 'zenclau_v1_product_insert_failed', __( 'V1: Could not create product.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return self::get_product( (int) $wpdb->insert_id );
		}

		/**
		 * Update product.
		 *
		 * @param int   $id Product id.
		 * @param array $data Product payload.
		 * @return array|WP_Error
		 */
		public static function update_product( $id, array $data ) {
			global $wpdb;

			self::maybe_install_tables();

			$id      = absint( $id );
			$current = self::get_product( $id );
			if ( ! $current ) {
				return new WP_Error( 'zenclau_v1_product_not_found', __( 'V1: Product not found.', 'bhdt-core-system' ), array( 'status' => 404 ) );
			}

			$payload = array(
				'name'            => sanitize_text_field( $data['name'] ?? $current['name'] ),
				'official_url'    => esc_url_raw( $data['official_url'] ?? $current['official_url'] ),
				'search_keywords' => sanitize_textarea_field( $data['search_keywords'] ?? $current['search_keywords'] ),
			);

			$updated = $wpdb->update(
				self::products_table(),
				$payload,
				array( 'id' => $id ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);

			if ( false === $updated ) {
				return new WP_Error( 'zenclau_v1_product_update_failed', __( 'V1: Could not update product.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return self::get_product( $id );
		}

		/**
		 * Delete product.
		 *
		 * @param int $id Product id.
		 * @return array|WP_Error
		 */
		public static function delete_product( $id ) {
			global $wpdb;

			self::maybe_install_tables();

			$id      = absint( $id );
			$current = self::get_product( $id );
			if ( ! $current ) {
				return new WP_Error( 'zenclau_v1_product_not_found', __( 'V1: Product not found.', 'bhdt-core-system' ), array( 'status' => 404 ) );
			}

			$wpdb->delete( self::posts_queue_table(), array( 'product_id' => $id ), array( '%d' ) );
			$deleted = $wpdb->delete( self::products_table(), array( 'id' => $id ), array( '%d' ) );

			if ( false === $deleted ) {
				return new WP_Error( 'zenclau_v1_product_delete_failed', __( 'V1: Could not delete product.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return array( 'deleted' => true, 'id' => $id );
		}

		/**
		 * Create queue item.
		 *
		 * @param array $data Queue payload.
		 * @return array|WP_Error
		 */
		public static function create_queue_item( array $data ) {
			global $wpdb;

			self::maybe_install_tables();

			$product_id  = absint( $data['product_id'] ?? 0 );
			$youtube_url = isset( $data['youtube_url'] ) ? esc_url_raw( $data['youtube_url'] ) : '';
			$status      = sanitize_key( $data['status'] ?? 'pending' );
			$status      = $status ? $status : 'pending';
			$content     = $data['content_json'] ?? array();

			if ( ! self::get_product( $product_id ) ) {
				return new WP_Error( 'zenclau_v1_queue_product_missing', __( 'V1: A valid product_id is required.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			if ( is_string( $content ) ) {
				$decoded = json_decode( $content, true );
				$content = is_array( $decoded ) ? $decoded : array();
			}

			if ( ! is_array( $content ) ) {
				return new WP_Error( 'zenclau_v1_queue_invalid_json', __( 'V1: content_json must be a JSON object.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$content_json = wp_json_encode( $content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
			if ( false === $content_json ) {
				return new WP_Error( 'zenclau_v1_queue_json_encode_failed', __( 'V1: Could not encode content_json.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$inserted = $wpdb->insert(
				self::posts_queue_table(),
				array(
					'product_id'   => $product_id,
					'youtube_url'  => $youtube_url,
					'content_json' => $content_json,
					'status'       => $status,
				),
				array( '%d', '%s', '%s', '%s' )
			);

			if ( false === $inserted ) {
				return new WP_Error( 'zenclau_v1_queue_insert_failed', __( 'V1: Could not create queue item.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return self::get_queue_item( (int) $wpdb->insert_id );
		}

		/**
		 * Get queue item.
		 *
		 * @param int $id Queue id.
		 * @return array|null
		 */
		public static function get_queue_item( $id ) {
			global $wpdb;

			self::maybe_install_tables();

			$row = $wpdb->get_row(
				$wpdb->prepare( 'SELECT * FROM ' . self::posts_queue_table() . ' WHERE id = %d', absint( $id ) )
			);

			return $row ? self::format_queue_item( $row ) : null;
		}

		/**
		 * Get pending queue.
		 *
		 * @return array
		 */
		public static function get_pending_queue() {
			global $wpdb;

			self::maybe_install_tables();

			$rows = $wpdb->get_results(
				$wpdb->prepare(
					'SELECT q.*, p.name AS product_name FROM ' . self::posts_queue_table() . ' q LEFT JOIN ' . self::products_table() . ' p ON p.id = q.product_id WHERE q.status = %s ORDER BY q.created_at ASC, q.id ASC',
					'pending'
				)
			);

			return array_map(
				static function ( $row ) {
					$item                 = self::format_queue_item( $row );
					$item['product_name'] = (string) ( $row->product_name ?? '' );
					return $item;
				},
				(array) $rows
			);
		}

		/**
		 * Get latest queue item for a product and YouTube URL.
		 *
		 * @param int    $product_id Product id.
		 * @param string $youtube_url YouTube URL.
		 * @return array|null
		 */
		public static function get_latest_queue_item_for_run( $product_id, $youtube_url ) {
			global $wpdb;

			self::maybe_install_tables();

			$row = $wpdb->get_row(
				$wpdb->prepare(
					'SELECT * FROM ' . self::posts_queue_table() . ' WHERE product_id = %d AND youtube_url = %s ORDER BY id DESC LIMIT 1',
					absint( $product_id ),
					(string) $youtube_url
				)
			);

			return $row ? self::format_queue_item( $row ) : null;
		}

		/**
		 * Update queue item.
		 *
		 * @param int   $id Queue id.
		 * @param array $data Queue payload.
		 * @return array|WP_Error
		 */
		public static function update_queue_item( $id, array $data ) {
			global $wpdb;

			self::maybe_install_tables();

			$id      = absint( $id );
			$current = self::get_queue_item( $id );
			if ( ! $current ) {
				return new WP_Error( 'zenclau_v1_queue_not_found', __( 'V1: Queue item not found.', 'bhdt-core-system' ), array( 'status' => 404 ) );
			}

			$payload = array();
			$formats = array();

			if ( isset( $data['status'] ) ) {
				$payload['status'] = sanitize_key( $data['status'] );
				$formats[]         = '%s';
			}

			if ( isset( $data['content_json'] ) ) {
				$content = $data['content_json'];
				if ( is_string( $content ) ) {
					$decoded = json_decode( $content, true );
					$content = is_array( $decoded ) ? $decoded : array();
				}
				if ( ! is_array( $content ) ) {
					return new WP_Error( 'zenclau_v1_queue_invalid_json', __( 'V1: content_json must be a JSON object.', 'bhdt-core-system' ), array( 'status' => 400 ) );
				}

				$content_json = wp_json_encode( $content, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				if ( false === $content_json ) {
					return new WP_Error( 'zenclau_v1_queue_json_encode_failed', __( 'V1: Could not encode content_json.', 'bhdt-core-system' ), array( 'status' => 500 ) );
				}

				$payload['content_json'] = $content_json;
				$formats[]               = '%s';
			}

			if ( empty( $payload ) ) {
				return $current;
			}

			$updated = $wpdb->update(
				self::posts_queue_table(),
				$payload,
				array( 'id' => $id ),
				$formats,
				array( '%d' )
			);

			if ( false === $updated ) {
				return new WP_Error( 'zenclau_v1_queue_update_failed', __( 'V1: Could not update queue item.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return self::get_queue_item( $id );
		}
	}
}

if ( ! class_exists( 'Zenclau_V1_REST_API' ) ) {
	/**
	 * REST API for Youtube Content System.
	 */
	final class Zenclau_V1_REST_API {
		/**
		 * Boot hooks.
		 *
		 * @return void
		 */
		public static function init() {
			$instance = new self();
			add_action( 'rest_api_init', array( $instance, 'register_routes' ) );
		}

		/**
		 * Register routes.
		 *
		 * @return void
		 */
		public function register_routes() {
			register_rest_route(
				'zenclau/v1',
				'/products',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'get_products' ),
					),
					array(
						'methods'             => WP_REST_Server::CREATABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'create_product' ),
					),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/products/(?P<id>\d+)',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'get_product' ),
					),
					array(
						'methods'             => WP_REST_Server::EDITABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'update_product' ),
					),
					array(
						'methods'             => WP_REST_Server::DELETABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'delete_product' ),
					),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/posts-queue',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'create_queue_item' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/posts-queue/pending',
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'get_pending_queue' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/posts-queue/(?P<id>\d+)',
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'update_queue_item' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/posts-queue/(?P<id>\d+)/finish',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'finish_queue_item' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/scraper/run',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'run_manual_scraper' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/scraper/transcript',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'get_youtube_transcript' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/scraper/official-text',
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'permission_callback' => array( $this, 'can_manage' ),
					'callback'            => array( $this, 'get_official_text' ),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/settings/gemini-api-key',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'get_gemini_api_key' ),
					),
					array(
						'methods'             => WP_REST_Server::EDITABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'update_gemini_api_key' ),
					),
				)
			);

			register_rest_route(
				'zenclau/v1',
				'/settings/schema-templates',
				array(
					array(
						'methods'             => WP_REST_Server::READABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'get_schema_templates' ),
					),
					array(
						'methods'             => WP_REST_Server::EDITABLE,
						'permission_callback' => array( $this, 'can_manage' ),
						'callback'            => array( $this, 'save_schema_template' ),
					),
				)
			);
		}

		/**
		 * Permission callback.
		 *
		 * @return bool|WP_Error
		 */
		public function can_manage() {
			if ( current_user_can( 'manage_options' ) ) {
				return true;
			}

			return new WP_Error( 'zenclau_v1_forbidden', __( 'V1: You do not have permission to manage Zenclau Content System.', 'bhdt-core-system' ), array( 'status' => 403 ) );
		}

		/**
		 * Return the configured Gemini API key for the admin settings panel.
		 *
		 * @return WP_REST_Response|WP_Error
		 */
		public function get_gemini_api_key() {
			$result = $this->read_env_value( 'GEMINI_API_KEY' );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return rest_ensure_response(
				array(
					'key'     => $result,
					'env_key' => 'GEMINI_API_KEY',
				)
			);
		}

		/**
		 * Update the Gemini API key in the plugin .env file.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function update_gemini_api_key( WP_REST_Request $request ) {
			$params  = (array) $request->get_json_params();
			$api_key = isset( $params['key'] ) ? sanitize_text_field( wp_unslash( $params['key'] ) ) : '';

			if ( '' === $api_key ) {
				return new WP_Error( 'zenclau_v1_gemini_key_empty', __( 'V1: Gemini API key cannot be empty.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$result = $this->write_env_value( 'GEMINI_API_KEY', $api_key );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return rest_ensure_response(
				array(
					'success' => true,
					'env_key' => 'GEMINI_API_KEY',
				)
			);
		}

		/**
		 * Read a single key from the plugin .env file.
		 *
		 * @param string $key Environment key.
		 * @return string|WP_Error
		 */
		private function read_env_value( $key ) {
			$env_file = BHDT_PATH . '.env';

			if ( ! file_exists( $env_file ) ) {
				return new WP_Error( 'zenclau_v1_env_missing', __( 'V1: .env file was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$contents = file_get_contents( $env_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( false === $contents ) {
				return new WP_Error( 'zenclau_v1_env_read_failed', __( 'V1: Could not read .env file.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$lines = preg_split( "/\r\n|\n|\r/", (string) $contents );
			foreach ( $lines as $line ) {
				if ( preg_match( '/^\s*' . preg_quote( $key, '/' ) . '\s*=\s*(.*)\s*$/', $line, $matches ) ) {
					return trim( (string) $matches[1], " \t\n\r\0\x0B\"'" );
				}
			}

			return '';
		}

		/**
		 * Write a single key to the plugin .env file while preserving other values.
		 *
		 * @param string $key Environment key.
		 * @param string $value Environment value.
		 * @return true|WP_Error
		 */
		private function write_env_value( $key, $value ) {
			$env_file = BHDT_PATH . '.env';

			if ( ! file_exists( $env_file ) ) {
				return new WP_Error( 'zenclau_v1_env_missing', __( 'V1: .env file was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			if ( ! is_writable( $env_file ) ) {
				return new WP_Error( 'zenclau_v1_env_not_writable', __( 'V1: .env file is not writable.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$contents = file_get_contents( $env_file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( false === $contents ) {
				return new WP_Error( 'zenclau_v1_env_read_failed', __( 'V1: Could not read .env file.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$line    = $key . '=' . $this->format_env_value( $value );
			$pattern = '/^' . preg_quote( $key, '/' ) . '=.*$/m';
			if ( preg_match( $pattern, (string) $contents ) ) {
				$contents = preg_replace( $pattern, $line, (string) $contents );
			} else {
				$contents = rtrim( (string) $contents ) . PHP_EOL . $line . PHP_EOL;
			}

			$written = file_put_contents( $env_file, $contents, LOCK_EX ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			if ( false === $written ) {
				return new WP_Error( 'zenclau_v1_env_write_failed', __( 'V1: Could not write .env file.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return true;
		}

		/**
		 * Quote an env value only when needed.
		 *
		 * @param string $value Raw value.
		 * @return string
		 */
		private function format_env_value( $value ) {
			$value = trim( (string) $value );
			if ( preg_match( '/[\s#"\']/', $value ) ) {
				return '"' . str_replace( array( '\\', '"' ), array( '\\\\', '\\"' ), $value ) . '"';
			}

			return $value;
		}

		/**
		 * Default Gemini schema templates.
		 *
		 * @return array
		 */
		private function default_schema_templates() {
			return array(
				array(
					'id'     => 'template_1',
					'name'   => 'Mẫu 1 - Review kỹ thuật',
					'schema' => "{\n  \"title\": \"string\",\n  \"summary\": \"string\",\n  \"review_content\": \"string\",\n  \"comparison_table\": [\n    {\n      \"criteria\": \"string\",\n      \"product_value\": \"string\",\n      \"notes\": \"string\"\n    }\n  ]\n}",
				),
			);
		}

		/**
		 * Get stored Gemini JSON schema templates.
		 *
		 * @return WP_REST_Response
		 */
		public function get_schema_templates() {
			$templates = get_option( 'zenclau_v1_schema_templates', array() );
			if ( ! is_array( $templates ) || empty( $templates ) ) {
				$templates = $this->default_schema_templates();
				update_option( 'zenclau_v1_schema_templates', $templates, false );
			}

			return rest_ensure_response(
				array(
					'templates' => array_values( $templates ),
				)
			);
		}

		/**
		 * Save or update one Gemini JSON schema template.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function save_schema_template( WP_REST_Request $request ) {
			$params = (array) $request->get_json_params();
			$id     = sanitize_key( $params['id'] ?? '' );
			$name   = sanitize_text_field( wp_unslash( $params['name'] ?? '' ) );
			$schema = isset( $params['schema'] ) ? trim( (string) wp_unslash( $params['schema'] ) ) : '';

			if ( '' === $name || '' === $schema ) {
				return new WP_Error( 'zenclau_v1_schema_template_missing', __( 'V1: Template name and schema are required.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$decoded_schema = json_decode( $schema, true );
			if ( ! is_array( $decoded_schema ) ) {
				return new WP_Error( 'zenclau_v1_schema_template_invalid_json', __( 'V1: Schema template must be valid JSON.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			if ( '' === $id || 'new' === $id ) {
				$id = 'template_' . time();
			}

			$templates = get_option( 'zenclau_v1_schema_templates', $this->default_schema_templates() );
			$templates = is_array( $templates ) ? array_values( $templates ) : $this->default_schema_templates();
			$saved     = array(
				'id'     => $id,
				'name'   => $name,
				'schema' => wp_json_encode( $decoded_schema, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			);
			$found     = false;

			foreach ( $templates as $index => $template ) {
				if ( is_array( $template ) && isset( $template['id'] ) && $template['id'] === $id ) {
					$templates[ $index ] = $saved;
					$found               = true;
					break;
				}
			}

			if ( ! $found ) {
				$templates[] = $saved;
			}

			update_option( 'zenclau_v1_schema_templates', $templates, false );

			return rest_ensure_response(
				array(
					'success'   => true,
					'template'  => $saved,
					'templates' => array_values( $templates ),
				)
			);
		}

		/**
		 * Products list.
		 *
		 * @return WP_REST_Response
		 */
		public function get_products() {
			return rest_ensure_response( Zenclau_V1_Content_Model::get_products() );
		}

		/**
		 * Single product.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function get_product( WP_REST_Request $request ) {
			$product = Zenclau_V1_Content_Model::get_product( absint( $request['id'] ) );
			if ( ! $product ) {
				return new WP_Error( 'zenclau_v1_product_not_found', __( 'V1: Product not found.', 'bhdt-core-system' ), array( 'status' => 404 ) );
			}

			return rest_ensure_response( $product );
		}

		/**
		 * Create product.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function create_product( WP_REST_Request $request ) {
			$result = Zenclau_V1_Content_Model::create_product( (array) $request->get_json_params() );
			return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
		}

		/**
		 * Update product.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function update_product( WP_REST_Request $request ) {
			$result = Zenclau_V1_Content_Model::update_product( absint( $request['id'] ), (array) $request->get_json_params() );
			return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
		}

		/**
		 * Delete product.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function delete_product( WP_REST_Request $request ) {
			$result = Zenclau_V1_Content_Model::delete_product( absint( $request['id'] ) );
			return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
		}

		/**
		 * Create queue item.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function create_queue_item( WP_REST_Request $request ) {
			$result = Zenclau_V1_Content_Model::create_queue_item( (array) $request->get_json_params() );
			return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
		}

		/**
		 * Pending queue list.
		 *
		 * @return WP_REST_Response
		 */
		public function get_pending_queue() {
			return rest_ensure_response( Zenclau_V1_Content_Model::get_pending_queue() );
		}

		/**
		 * Update queue item.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function update_queue_item( WP_REST_Request $request ) {
			$result = Zenclau_V1_Content_Model::update_queue_item( absint( $request['id'] ), (array) $request->get_json_params() );
			return is_wp_error( $result ) ? $result : rest_ensure_response( $result );
		}

		/**
		 * Finish a queue item by creating a pending WordPress post for later editing.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function finish_queue_item( WP_REST_Request $request ) {
			$id      = absint( $request['id'] );
			$params  = (array) $request->get_json_params();
			$current = Zenclau_V1_Content_Model::get_queue_item( $id );

			if ( ! $current ) {
				return new WP_Error( 'zenclau_v1_queue_not_found', __( 'V1: Queue item not found.', 'bhdt-core-system' ), array( 'status' => 404 ) );
			}

			$destination = $this->normalize_finish_destination( $params['destination'] ?? 'post' );
			if ( is_wp_error( $destination ) ) {
				return $destination;
			}

			$content = $current['content_json'];
			if ( isset( $params['content_json'] ) && is_array( $params['content_json'] ) ) {
				$content = array_merge( $content, $params['content_json'] );
			}

			$title          = sanitize_text_field( $content['title'] ?? '' );
			$summary        = sanitize_textarea_field( $content['summary'] ?? '' );
			$review_content = sanitize_textarea_field( $content['review_content'] ?? ( $content['body'] ?? '' ) );

			if ( '' === $title ) {
				return new WP_Error( 'zenclau_v1_finish_missing_title', __( 'V1: Title is required before finishing.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$content['title']          = $title;
			$content['summary']        = $summary;
			$content['review_content'] = $review_content;

			$postarr = array(
				'post_type'    => $destination['post_type'],
				'post_status'  => 'pending',
				'post_title'   => $title,
				'post_excerpt' => $summary,
				'post_content' => $this->build_finished_post_content( $content, $current ),
			);

			$post_id = wp_insert_post( wp_slash( $postarr ), true );
			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}

			update_post_meta( $post_id, '_zenclau_v1_queue_id', $id );
			update_post_meta( $post_id, '_zenclau_v1_product_id', absint( $current['product_id'] ) );
			update_post_meta( $post_id, '_zenclau_v1_youtube_url', esc_url_raw( $current['youtube_url'] ) );
			update_post_meta( $post_id, '_zenclau_v1_destination', $destination['key'] );

			if ( ! empty( $content['comparison_table'] ) ) {
				$comparison_json = wp_json_encode( $content['comparison_table'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				if ( false !== $comparison_json ) {
					update_post_meta( $post_id, 'bhdt_specs', $comparison_json );
					if ( 'bhdt_comparison' === $destination['post_type'] ) {
						update_post_meta( $post_id, '_bhdt_comparison_specs', $comparison_json );
					}
				}
			}

			$content['finished_destination'] = $destination['key'];
			$content['finished_post_type']   = $destination['post_type'];
			$content['finished_post_id']     = (int) $post_id;
			$content['finished_at']          = current_time( 'mysql' );

			$updated = Zenclau_V1_Content_Model::update_queue_item(
				$id,
				array(
					'status'       => 'finished',
					'content_json' => $content,
				)
			);
			if ( is_wp_error( $updated ) ) {
				return $updated;
			}

			return rest_ensure_response(
				array(
					'success'     => true,
					'queue_item'  => $updated,
					'post_id'     => (int) $post_id,
					'post_type'   => $destination['post_type'],
					'destination' => $destination['key'],
					'edit_url'    => get_edit_post_link( $post_id, 'raw' ),
					'status'      => 'pending',
				)
			);
		}

		/**
		 * Normalize Finish destination into a WordPress post type.
		 *
		 * @param string $destination Destination key.
		 * @return array|WP_Error
		 */
		private function normalize_finish_destination( $destination ) {
			$key = sanitize_key( (string) $destination );
			$map = array(
				'post'       => array(
					'key'       => 'post',
					'post_type' => 'post',
				),
				'review'     => array(
					'key'       => 'review',
					'post_type' => 'bhdt_review',
				),
				'comparison' => array(
					'key'       => 'comparison',
					'post_type' => 'bhdt_comparison',
				),
			);

			if ( ! isset( $map[ $key ] ) ) {
				return new WP_Error( 'zenclau_v1_finish_invalid_destination', __( 'V1: Finish destination must be Post, Review, or So sanh.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			if ( ! post_type_exists( $map[ $key ]['post_type'] ) ) {
				return new WP_Error(
					'zenclau_v1_finish_missing_post_type',
					sprintf( 'V1: Post type %s is not registered yet.', $map[ $key ]['post_type'] ),
					array( 'status' => 500 )
				);
			}

			return $map[ $key ];
		}

		/**
		 * Build editable HTML content for the destination post.
		 *
		 * @param array $content Queue content JSON.
		 * @param array $queue_item Queue item.
		 * @return string
		 */
		private function build_finished_post_content( array $content, array $queue_item ) {
			$summary        = (string) ( $content['summary'] ?? '' );
			$review_content = (string) ( $content['review_content'] ?? '' );
			$youtube_url    = esc_url_raw( $queue_item['youtube_url'] ?? '' );
			$html           = '';

			if ( '' !== trim( $summary ) ) {
				$html .= '<h2>Tóm tắt</h2>' . wpautop( esc_html( $summary ) );
			}

			if ( '' !== trim( $review_content ) ) {
				$html .= '<h2>Nội dung review</h2>' . wpautop( esc_html( $review_content ) );
			}

			if ( ! empty( $content['comparison_table'] ) && is_array( $content['comparison_table'] ) ) {
				$html .= '<h2>Bảng so sánh</h2>';
				$html .= '<table><thead><tr><th>Tiêu chí</th><th>Giá trị</th><th>Ghi chú</th></tr></thead><tbody>';
				foreach ( $content['comparison_table'] as $row ) {
					if ( ! is_array( $row ) ) {
						continue;
					}
					$html .= '<tr>';
					$html .= '<td>' . esc_html( $row['criteria'] ?? '' ) . '</td>';
					$html .= '<td>' . esc_html( $row['product_value'] ?? '' ) . '</td>';
					$html .= '<td>' . esc_html( $row['notes'] ?? '' ) . '</td>';
					$html .= '</tr>';
				}
				$html .= '</tbody></table>';
			}

			$known_fields = array( 'title', 'summary', 'review_content', 'body', 'comparison_table' );
			foreach ( $content as $key => $value ) {
				if ( in_array( $key, $known_fields, true ) || null === $value || '' === $value ) {
					continue;
				}
				$html .= '<h2>' . esc_html( $this->humanize_schema_key( $key ) ) . '</h2>';
				if ( is_array( $value ) || is_object( $value ) ) {
					$json = wp_json_encode( $value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
					$html .= '<pre>' . esc_html( false === $json ? '' : $json ) . '</pre>';
				} else {
					$html .= wpautop( esc_html( (string) $value ) );
				}
			}

			if ( '' !== $youtube_url ) {
				$html .= '<p><strong>YouTube source:</strong> <a href="' . esc_url( $youtube_url ) . '">' . esc_html( $youtube_url ) . '</a></p>';
			}

			return $html;
		}

		/**
		 * Convert a JSON key into a readable section title.
		 *
		 * @param string $key JSON key.
		 * @return string
		 */
		private function humanize_schema_key( $key ) {
			$key = str_replace( array( '_', '-' ), ' ', (string) $key );
			return ucwords( $key );
		}

		/**
		 * Run the Python V1 scraper.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function run_manual_scraper( WP_REST_Request $request ) {
			$params      = (array) $request->get_json_params();
			$product_id  = absint( $params['product_id'] ?? 0 );
			$youtube_url = esc_url_raw( $params['youtube_url'] ?? '' );
			$prompt_rules = isset( $params['prompt_rules'] ) ? sanitize_textarea_field( wp_unslash( $params['prompt_rules'] ) ) : '';
			$json_schema = isset( $params['json_schema'] ) ? trim( (string) wp_unslash( $params['json_schema'] ) ) : '';
			$product     = Zenclau_V1_Content_Model::get_product( $product_id );

			if ( ! $product || '' === $youtube_url ) {
				return new WP_Error( 'zenclau_v1_scraper_missing_fields', __( 'V1: Product ID and YouTube URL are required.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$result = $this->run_worker_process( $product_id, $youtube_url, $prompt_rules, $json_schema );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$item = Zenclau_V1_Content_Model::get_latest_queue_item_for_run( $product_id, $youtube_url );
			if ( ! $item ) {
				return new WP_Error( 'zenclau_v1_scraper_no_queue_item', __( 'V1: Worker finished but did not create a queue item.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return rest_ensure_response( $item );
		}

		/**
		 * Resolve Python executable for PHP processes that do not inherit the user PATH.
		 *
		 * @return string
		 */
		private function get_python_bin() {
			$default_candidates = array(
				getenv( 'ZENCLAU_PYTHON_BIN' ),
				'C:\\Program Files\\Python311\\python.exe',
				'C:\\Users\\Tuan\\AppData\\Local\\Programs\\Python\\Python311\\python.exe',
				'python',
			);
			$candidates          = (array) apply_filters( 'zenclau_v1_python_bin_candidates', $default_candidates );

			foreach ( $candidates as $candidate ) {
				$candidate = is_string( $candidate ) ? trim( $candidate ) : '';
				if ( '' === $candidate ) {
					continue;
				}
				if ( 'python' === $candidate || file_exists( $candidate ) ) {
					return (string) apply_filters( 'zenclau_v1_python_bin', $candidate );
				}
			}

			return (string) apply_filters( 'zenclau_v1_python_bin', 'python' );
		}

		/**
		 * Fetch and return a YouTube transcript for review before scraping.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function get_youtube_transcript( WP_REST_Request $request ) {
			$params      = (array) $request->get_json_params();
			$youtube_url = esc_url_raw( $params['youtube_url'] ?? '' );
			$languages   = sanitize_text_field( $params['languages'] ?? 'vi,en' );

			if ( '' === $youtube_url ) {
				return new WP_Error( 'zenclau_v1_transcript_missing_url', __( 'V1: YouTube URL is required.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$result = $this->run_transcript_process( $youtube_url, $languages );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return rest_ensure_response( $result );
		}

		/**
		 * Fetch extracted official_url text for review before scraping.
		 *
		 * @param WP_REST_Request $request Request.
		 * @return WP_REST_Response|WP_Error
		 */
		public function get_official_text( WP_REST_Request $request ) {
			$params     = (array) $request->get_json_params();
			$product_id = absint( $params['product_id'] ?? 0 );

			if ( ! Zenclau_V1_Content_Model::get_product( $product_id ) ) {
				return new WP_Error( 'zenclau_v1_official_text_missing_product', __( 'V1: Product ID is required.', 'bhdt-core-system' ), array( 'status' => 400 ) );
			}

			$result = $this->run_official_text_process( $product_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			return rest_ensure_response( $result );
		}

		/**
		 * Execute worker script and capture output for diagnostics.
		 *
		 * @param int    $product_id Product id.
		 * @param string $youtube_url YouTube URL.
		 * @param string $prompt_rules Gemini prompt rules.
		 * @param string $json_schema Gemini JSON schema prompt.
		 * @return true|WP_Error
		 */
		private function run_worker_process( $product_id, $youtube_url, $prompt_rules = '', $json_schema = '' ) {
			$script   = BHDT_PATH . 'zenclau_worker_v1.py';
			$env_file = BHDT_PATH . '.env';

			if ( ! file_exists( $script ) ) {
				return new WP_Error( 'zenclau_v1_worker_missing', __( 'V1: zenclau_worker_v1.py was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			if ( ! file_exists( $env_file ) ) {
				return new WP_Error( 'zenclau_v1_env_missing', __( 'V1: .env file was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			if ( ! function_exists( 'proc_open' ) ) {
				return new WP_Error( 'zenclau_v1_proc_open_disabled', __( 'V1: proc_open is disabled, so WordPress cannot run the Python worker.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$python = $this->get_python_bin();
			$cmd    = escapeshellarg( $python )
				. ' ' . escapeshellarg( $script )
				. ' --youtube-url ' . escapeshellarg( $youtube_url )
				. ' --product-id ' . absint( $product_id )
				. ' --env-file ' . escapeshellarg( $env_file )
				. ' --allow-missing-transcript';
			if ( '' !== trim( $prompt_rules ) ) {
				$cmd .= ' --prompt-rules-b64 ' . escapeshellarg( base64_encode( $prompt_rules ) );
			}
			if ( '' !== trim( $json_schema ) ) {
				$cmd .= ' --json-schema-b64 ' . escapeshellarg( base64_encode( $json_schema ) );
			}

			$descriptor_spec = array(
				0 => array( 'pipe', 'r' ),
				1 => array( 'pipe', 'w' ),
				2 => array( 'pipe', 'w' ),
			);

			$process = proc_open( $cmd, $descriptor_spec, $pipes, BHDT_PATH );
			if ( ! is_resource( $process ) ) {
				return new WP_Error( 'zenclau_v1_worker_start_failed', __( 'V1: Could not start Python worker.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			fclose( $pipes[0] );
			$stdout    = stream_get_contents( $pipes[1] );
			$stderr    = stream_get_contents( $pipes[2] );
			$exit_code = proc_close( $process );

			if ( 0 !== $exit_code ) {
				$output = trim( (string) $stdout . "\n" . (string) $stderr );
				return new WP_Error(
					'zenclau_v1_worker_failed',
					sprintf( 'V1: Python worker failed with exit code %d. %s', (int) $exit_code, $output ),
					array( 'status' => 500 )
				);
			}

			return true;
		}

		/**
		 * Execute worker transcript-only mode.
		 *
		 * @param string $youtube_url YouTube URL.
		 * @param string $languages Transcript language priority.
		 * @return array|WP_Error
		 */
		private function run_transcript_process( $youtube_url, $languages ) {
			$script = BHDT_PATH . 'zenclau_worker_v1.py';

			if ( ! file_exists( $script ) ) {
				return new WP_Error( 'zenclau_v1_worker_missing', __( 'V1: zenclau_worker_v1.py was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			if ( ! function_exists( 'proc_open' ) ) {
				return new WP_Error( 'zenclau_v1_proc_open_disabled', __( 'V1: proc_open is disabled, so WordPress cannot run the Python worker.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$python = $this->get_python_bin();
			$cmd    = escapeshellarg( $python )
				. ' ' . escapeshellarg( $script )
				. ' --youtube-url ' . escapeshellarg( $youtube_url )
				. ' --languages ' . escapeshellarg( $languages )
				. ' --transcript-only';

			$descriptor_spec = array(
				0 => array( 'pipe', 'r' ),
				1 => array( 'pipe', 'w' ),
				2 => array( 'pipe', 'w' ),
			);

			$process = proc_open( $cmd, $descriptor_spec, $pipes, BHDT_PATH );
			if ( ! is_resource( $process ) ) {
				return new WP_Error( 'zenclau_v1_worker_start_failed', __( 'V1: Could not start Python worker.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			fclose( $pipes[0] );
			$stdout    = stream_get_contents( $pipes[1] );
			$stderr    = stream_get_contents( $pipes[2] );
			$exit_code = proc_close( $process );
			$payload   = json_decode( trim( (string) $stdout ), true );

			if ( 0 !== $exit_code ) {
				$message = is_array( $payload ) && ! empty( $payload['error'] ) ? $payload['error'] : trim( (string) $stdout . "\n" . (string) $stderr );
				return new WP_Error(
					'zenclau_v1_transcript_failed',
					sprintf( 'V1: Could not fetch transcript. %s', $message ),
					array( 'status' => 500 )
				);
			}

			if ( ! is_array( $payload ) || empty( $payload['transcript'] ) ) {
				return new WP_Error( 'zenclau_v1_transcript_invalid_output', __( 'V1: Transcript worker returned invalid output.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return $payload;
		}

		/**
		 * Execute worker official-text-only mode.
		 *
		 * @param int $product_id Product id.
		 * @return array|WP_Error
		 */
		private function run_official_text_process( $product_id ) {
			$script   = BHDT_PATH . 'zenclau_worker_v1.py';
			$env_file = BHDT_PATH . '.env';

			if ( ! file_exists( $script ) ) {
				return new WP_Error( 'zenclau_v1_worker_missing', __( 'V1: zenclau_worker_v1.py was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			if ( ! file_exists( $env_file ) ) {
				return new WP_Error( 'zenclau_v1_env_missing', __( 'V1: .env file was not found.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			if ( ! function_exists( 'proc_open' ) ) {
				return new WP_Error( 'zenclau_v1_proc_open_disabled', __( 'V1: proc_open is disabled, so WordPress cannot run the Python worker.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			$python = $this->get_python_bin();
			$cmd    = escapeshellarg( $python )
				. ' ' . escapeshellarg( $script )
				. ' --youtube-url ' . escapeshellarg( 'https://www.youtube.com/watch?v=dummy' )
				. ' --product-id ' . absint( $product_id )
				. ' --env-file ' . escapeshellarg( $env_file )
				. ' --official-text-only';

			$descriptor_spec = array(
				0 => array( 'pipe', 'r' ),
				1 => array( 'pipe', 'w' ),
				2 => array( 'pipe', 'w' ),
			);

			$process = proc_open( $cmd, $descriptor_spec, $pipes, BHDT_PATH );
			if ( ! is_resource( $process ) ) {
				return new WP_Error( 'zenclau_v1_worker_start_failed', __( 'V1: Could not start Python worker.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			fclose( $pipes[0] );
			$stdout    = stream_get_contents( $pipes[1] );
			$stderr    = stream_get_contents( $pipes[2] );
			$exit_code = proc_close( $process );
			$payload   = json_decode( trim( (string) $stdout ), true );

			if ( 0 !== $exit_code ) {
				$message = is_array( $payload ) && ! empty( $payload['error'] ) ? $payload['error'] : trim( (string) $stdout . "\n" . (string) $stderr );
				return new WP_Error(
					'zenclau_v1_official_text_failed',
					sprintf( 'V1: Could not extract official text. %s', $message ),
					array( 'status' => 500 )
				);
			}

			if ( ! is_array( $payload ) || ! isset( $payload['text'] ) ) {
				return new WP_Error( 'zenclau_v1_official_text_invalid_output', __( 'V1: Official text worker returned invalid output.', 'bhdt-core-system' ), array( 'status' => 500 ) );
			}

			return $payload;
		}
	}
}

if ( ! class_exists( 'Zenclau_V1_Admin_UI' ) ) {
	/**
	 * Admin UI for Youtube Content System.
	 */
	final class Zenclau_V1_Admin_UI {
		/**
		 * Boot hooks.
		 *
		 * @return void
		 */
		public static function init() {
			$instance = new self();
			add_action( 'admin_menu', array( $instance, 'register_menu' ) );
		}

		/**
		 * Register admin menu.
		 *
		 * @return void
		 */
		public function register_menu() {
			add_menu_page(
				__( 'Youtube Content', 'bhdt-core-system' ),
				__( 'Youtube Content', 'bhdt-core-system' ),
				'manage_options',
				'zenclau-v1-content',
				array( $this, 'render_page' ),
				'dashicons-database-view',
				58
			);
		}

		/**
		 * Render admin page.
		 *
		 * @return void
		 */
		public function render_page() {
			Zenclau_V1_Content_Model::maybe_install_tables();
			$default_prompt_rules = "- Use Vietnamese.\n- Be factual and cautious. If evidence is missing, say it needs verification.\n- First mentally normalize the YouTube transcript by restoring sentence boundaries and punctuation from context.\n- Do not add facts during transcript normalization; only use it to understand the source better.\n- Use the YouTube transcript for hands-on observations.\n- Use the official Markdown for specifications and official claims.\n- Do not invent prices or certifications.\n- Keep comparison_table to 4-8 rows.";
			$default_json_schema  = "{\n  \"title\": \"string\",\n  \"summary\": \"string\",\n  \"review_content\": \"string\",\n  \"comparison_table\": [\n    {\n      \"criteria\": \"string\",\n      \"product_value\": \"string\",\n      \"notes\": \"string\"\n    }\n  ]\n}";
			?>
			<div class="wrap zenclau-v1-admin" data-zenclau-v1-admin>
				<h1>Youtube Content System</h1>
				<p class="description">Quản lý products, lấy transcript YouTube, chạy scraper thủ công và duyệt Content Queue.</p>

				<nav class="zenclau-v1-tabs" aria-label="Youtube Content tabs">
					<button type="button" class="is-active" data-tab="products">Products Manager</button>
					<button type="button" data-tab="scraper">Scraper Control</button>
					<button type="button" data-tab="queue">Content Queue</button>
				</nav>

				<section class="zenclau-v1-panel is-active" data-panel="products">
					<div class="zenclau-v1-grid">
						<form class="zenclau-v1-card" data-product-form>
							<h2>Thêm sản phẩm mới</h2>
							<label>
								<span>Name</span>
								<input type="text" name="name" required placeholder="ESP32-S3 WROOM" />
							</label>
							<label>
								<span>Official URL</span>
								<input type="url" name="official_url" placeholder="Không bắt buộc nếu chỉ dùng YouTube" />
							</label>
							<label>
								<span>Search keywords</span>
								<textarea name="search_keywords" required rows="4" placeholder="esp32 s3, esp32-s3 review, board devkit"></textarea>
							</label>
							<button type="submit" class="button button-primary">Lưu Product</button>
						</form>

						<div class="zenclau-v1-card">
							<h2>Danh sách products</h2>
							<div class="zenclau-v1-list" data-products-list></div>
						</div>
					</div>
				</section>

				<section class="zenclau-v1-panel" data-panel="scraper">
					<form class="zenclau-v1-card zenclau-v1-compact zenclau-v1-settings-card" data-gemini-key-form>
						<h2>Gemini API key</h2>
						<label>
							<span>GEMINI_API_KEY</span>
							<div class="zenclau-v1-inline-control">
								<input type="password" name="key" autocomplete="off" data-gemini-key-input />
								<button type="button" class="button" data-gemini-key-toggle>Show</button>
							</div>
						</label>
						<button type="submit" class="button button-secondary">Save API key</button>
					</form>

					<form class="zenclau-v1-card zenclau-v1-compact" data-scraper-form>
						<h2>Scraper Control</h2>
						<label>
							<span>YouTube URL</span>
							<input type="url" name="youtube_url" required placeholder="https://www.youtube.com/watch?v=..." />
						</label>
						<label>
							<span>Transcript languages</span>
							<input type="text" name="languages" value="vi,en" />
						</label>
						<label>
							<span>Product ID</span>
							<select name="product_id" required data-products-select></select>
						</label>
						<label>
							<span>Gemini prompt rules</span>
							<textarea name="prompt_rules" rows="9"><?php echo esc_textarea( $default_prompt_rules ); ?></textarea>
						</label>
						<div class="zenclau-v1-schema-tools">
							<label>
								<span>JSON schema template</span>
								<select name="schema_template_id" data-schema-template-select></select>
							</label>
							<label>
								<span>Template name</span>
								<input type="text" name="schema_template_name" value="Mẫu 1 - Review kỹ thuật" data-schema-template-name />
							</label>
							<label>
								<span>Gemini JSON schema prompt</span>
								<textarea name="json_schema" rows="12" data-json-schema-input><?php echo esc_textarea( $default_json_schema ); ?></textarea>
							</label>
							<div class="zenclau-v1-row-actions">
								<button type="button" class="button" data-schema-template-new>New template</button>
								<button type="button" class="button" data-schema-template-save>Save template</button>
							</div>
						</div>
						<button type="button" class="button" data-transcript-check>Check Transcript</button>
						<button type="button" class="button" data-official-text-check>Check PDF / Official Text</button>
						<button type="submit" class="button button-primary">Run Scraper</button>
						<label>
							<span>Transcript preview</span>
							<textarea rows="12" readonly data-transcript-output></textarea>
						</label>
						<label>
							<span>PDF / official text preview</span>
							<textarea rows="12" readonly data-official-text-output></textarea>
						</label>
					</form>
				</section>

				<section class="zenclau-v1-panel" data-panel="queue">
					<div class="zenclau-v1-grid zenclau-v1-editor-grid">
						<div class="zenclau-v1-card">
							<h2>Pending posts</h2>
							<div class="zenclau-v1-list" data-queue-list></div>
						</div>
						<form class="zenclau-v1-card" data-editor-form>
							<h2>Editor</h2>
							<input type="hidden" name="id" />
							<label>
								<span>Title</span>
								<input type="text" name="title" required />
							</label>
							<label>
								<span>Summary</span>
								<textarea name="summary" rows="4"></textarea>
							</label>
							<label>
								<span>Body</span>
								<textarea name="body" rows="12"></textarea>
							</label>
							<label>
								<span>Finish to</span>
								<select name="destination">
									<option value="post">Posts</option>
									<option value="review">Review</option>
									<option value="comparison">So sanh</option>
								</select>
							</label>
							<button type="submit" class="button button-primary">Finish</button>
						</form>
					</div>
				</section>

				<div class="zenclau-v1-toast" data-toast hidden></div>
			</div>

			<style>
				.zenclau-v1-admin {
					max-width: min(100%, 1420px);
					margin-right: 28px;
					color: #1d2327;
				}

				.zenclau-v1-admin h1 {
					margin: 26px 0 6px;
					font-size: 28px;
					font-weight: 700;
					letter-spacing: 0;
				}

				.zenclau-v1-admin > .description {
					margin: 0 0 20px;
					color: #646970;
					font-size: 14px;
				}

				.zenclau-v1-tabs {
					display: inline-flex;
					flex-wrap: wrap;
					gap: 6px;
					margin: 0 0 18px;
					padding: 6px;
					border: 1px solid #dcdcde;
					border-radius: 8px;
					background: #ffffff;
					box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
				}

				.zenclau-v1-tabs button {
					appearance: none;
					border: 0;
					border-radius: 6px;
					background: transparent;
					color: #50575e;
					padding: 10px 16px;
					font-weight: 700;
					line-height: 1.2;
					cursor: pointer;
				}

				.zenclau-v1-tabs button:hover,
				.zenclau-v1-tabs button:focus-visible {
					background: #f0f6fc;
					color: #0a4b78;
				}

				.zenclau-v1-tabs button.is-active {
					background: #135e96;
					color: #ffffff;
					box-shadow: 0 6px 16px rgba(19, 94, 150, 0.18);
				}

				.zenclau-v1-panel {
					display: none;
				}

				.zenclau-v1-panel.is-active {
					display: block;
				}

				.zenclau-v1-grid {
					display: grid;
					grid-template-columns: minmax(340px, 0.8fr) minmax(520px, 1.2fr);
					align-items: stretch;
					gap: 22px;
				}

				.zenclau-v1-editor-grid {
					grid-template-columns: minmax(360px, 0.72fr) minmax(620px, 1.28fr);
				}

				.zenclau-v1-card {
					display: grid;
					align-content: start;
					gap: 16px;
					min-height: 360px;
					padding: 24px;
					border: 1px solid #dcdcde;
					border-radius: 8px;
					background: #ffffff;
					box-shadow: 0 10px 28px rgba(0, 0, 0, 0.045);
				}

				.zenclau-v1-compact {
					max-width: 860px;
					min-height: 0;
				}

				.zenclau-v1-settings-card {
					margin-bottom: 18px;
				}

				.zenclau-v1-inline-control {
					display: grid;
					grid-template-columns: minmax(0, 1fr) auto;
					gap: 8px;
					align-items: center;
				}

				.zenclau-v1-schema-tools {
					display: grid;
					gap: 12px;
					padding: 14px;
					border: 1px solid #dcdcde;
					border-radius: 8px;
					background: #f8fafc;
				}

				.zenclau-v1-card h2 {
					margin: 0;
					font-size: 18px;
					font-weight: 700;
					line-height: 1.3;
				}

				.zenclau-v1-card label {
					display: grid;
					gap: 8px;
					color: #1d2327;
					font-weight: 700;
				}

				.zenclau-v1-card input,
				.zenclau-v1-card textarea,
				.zenclau-v1-card select {
					width: 100%;
					max-width: none;
					min-height: 42px;
					border-color: #c3c4c7;
					border-radius: 6px;
					padding: 9px 12px;
					font-size: 14px;
					line-height: 1.45;
					box-shadow: none;
				}

				.zenclau-v1-card textarea {
					min-height: 128px;
					resize: vertical;
				}

				.zenclau-v1-card input:focus,
				.zenclau-v1-card textarea:focus,
				.zenclau-v1-card select:focus {
					border-color: #2271b1;
					box-shadow: 0 0 0 2px rgba(34, 113, 177, 0.16);
				}

				.zenclau-v1-card .button-primary {
					min-height: 42px;
					border-radius: 6px;
					font-weight: 700;
				}

				.zenclau-v1-list {
					display: grid;
					align-content: start;
					gap: 10px;
					min-height: 220px;
				}

				.zenclau-v1-row {
					display: grid;
					gap: 7px;
					padding: 14px;
					border: 1px solid #dcdcde;
					border-radius: 8px;
					background: #f8fafc;
					color: #1d2327;
					text-align: left;
				}

				button.zenclau-v1-row {
					cursor: pointer;
				}

				button.zenclau-v1-row:hover,
				button.zenclau-v1-row:focus-visible {
					border-color: #2271b1;
					background: #f0f6fc;
					box-shadow: 0 0 0 2px rgba(34, 113, 177, 0.1);
				}

				.zenclau-v1-row strong {
					font-size: 14px;
				}

				.zenclau-v1-row span,
				.zenclau-v1-row small {
					color: #646970;
				}

				.zenclau-v1-row-actions {
					display: flex;
					flex-wrap: wrap;
					gap: 8px;
					margin-top: 4px;
				}

				.zenclau-v1-admin .button.is-busy {
					display: inline-flex;
					align-items: center;
					justify-content: center;
					gap: 8px;
					pointer-events: none;
					opacity: 0.82;
				}

				.zenclau-v1-spinner {
					width: 14px;
					height: 14px;
					border: 2px solid currentColor;
					border-right-color: transparent;
					border-radius: 50%;
					animation: zenclau-v1-spin 0.72s linear infinite;
				}

				@keyframes zenclau-v1-spin {
					to {
						transform: rotate(360deg);
					}
				}

				.zenclau-v1-toast {
					position: fixed;
					right: 24px;
					bottom: 24px;
					z-index: 100000;
					padding: 12px 16px;
					border-radius: 8px;
					background: #1d2327;
					box-shadow: 0 10px 28px rgba(0, 0, 0, 0.22);
					color: #ffffff;
				}

				@media (max-width: 1100px) {
					.zenclau-v1-grid,
					.zenclau-v1-editor-grid {
						grid-template-columns: 1fr;
					}

					.zenclau-v1-card {
						min-height: 0;
					}
				}

				@media (max-width: 782px) {
					.zenclau-v1-admin {
						margin-right: 12px;
					}

					.zenclau-v1-tabs {
						display: grid;
					}
				}
			</style>

			<script>
			(() => {
				const root = document.querySelector('[data-zenclau-v1-admin]');
				if (!root) return;

				const apiBase = <?php echo wp_json_encode( esc_url_raw( rest_url( 'zenclau/v1' ) ) ); ?>;
				const nonce = <?php echo wp_json_encode( wp_create_nonce( 'wp_rest' ) ); ?>;
				let products = [];
				let pendingPosts = [];
				let schemaTemplates = [];

				const request = async (path, options = {}) => {
					const response = await fetch(`${apiBase}${path}`, {
						...options,
						headers: {
							'Content-Type': 'application/json',
							'X-WP-Nonce': nonce,
							...(options.headers || {}),
						},
					});
					const data = await response.json().catch(() => ({}));
					if (!response.ok) {
						throw new Error(data.message || 'Youtube Content API error');
					}
					return data;
				};

				const toast = (message) => {
					const el = root.querySelector('[data-toast]');
					el.textContent = message;
					el.hidden = false;
					window.setTimeout(() => {
						el.hidden = true;
					}, 2600);
				};

				const setButtonBusy = (button, busy, label = 'Processing...') => {
					if (!button) return;
					if (busy) {
						button.dataset.idleText = button.textContent.trim();
						button.disabled = true;
						button.classList.add('is-busy');
						button.innerHTML = `<span class="zenclau-v1-spinner" aria-hidden="true"></span><span>${escapeHtml(label)}</span>`;
						return;
					}
					button.disabled = false;
					button.classList.remove('is-busy');
					button.textContent = button.dataset.idleText || button.textContent;
					delete button.dataset.idleText;
				};

				const withBusy = async (button, label, task) => {
					if (button?.disabled) return;
					setButtonBusy(button, true, label);
					try {
						return await task();
					} catch (error) {
						toast(error.message || 'Request failed.');
						return undefined;
					} finally {
						setButtonBusy(button, false);
					}
				};

				const escapeHtml = (value) => String(value || '').replace(/[&<>"']/g, (char) => ({
					'&': '&amp;',
					'<': '&lt;',
					'>': '&gt;',
					'"': '&quot;',
					"'": '&#039;',
				}[char]));

				const renderProducts = () => {
					const list = root.querySelector('[data-products-list]');
					const select = root.querySelector('[data-products-select]');
					list.innerHTML = products.length ? products.map((product) => `
						<div class="zenclau-v1-row">
							<strong>#${product.id} - ${escapeHtml(product.name)}</strong>
							<span>${product.official_url ? escapeHtml(product.official_url) : 'Chưa có Official URL, sẽ dùng transcript YouTube làm nguồn chính.'}</span>
							<small>${escapeHtml(product.search_keywords)}</small>
							<div class="zenclau-v1-row-actions">
								<button type="button" class="button" data-delete-product="${product.id}">Xóa</button>
							</div>
						</div>
					`).join('') : '<p>Chưa có product nào.</p>';

					select.innerHTML = products.length ? products.map((product) => (
						`<option value="${product.id}">#${product.id} - ${escapeHtml(product.name)}</option>`
					)).join('') : '<option value="">Thêm product trước</option>';
				};

				const renderQueue = () => {
					const list = root.querySelector('[data-queue-list]');
					list.innerHTML = pendingPosts.length ? pendingPosts.map((item) => `
						<button type="button" class="zenclau-v1-row" data-open-post="${item.id}">
							<strong>#${item.id} - ${escapeHtml(item.content_json?.title || 'Untitled draft')}</strong>
							<span>${escapeHtml(item.product_name || `Product #${item.product_id}`)}</span>
							<small>${escapeHtml(item.youtube_url || '')}</small>
						</button>
					`).join('') : '<p>Không có post pending.</p>';
				};

				const loadProducts = async () => {
					products = await request('/products');
					renderProducts();
				};

				const loadQueue = async () => {
					pendingPosts = await request('/posts-queue/pending');
					renderQueue();
				};

				const loadGeminiKey = async () => {
					const form = root.querySelector('[data-gemini-key-form]');
					if (!form) return;
					const result = await request('/settings/gemini-api-key');
					form.elements.key.value = result.key || '';
				};

				const applySchemaTemplate = (template) => {
					const form = root.querySelector('[data-scraper-form]');
					if (!form || !template) return;
					form.elements.schema_template_id.value = template.id || '';
					form.elements.schema_template_name.value = template.name || '';
					form.elements.json_schema.value = template.schema || '';
				};

				const renderSchemaTemplates = () => {
					const select = root.querySelector('[data-schema-template-select]');
					if (!select) return;
					select.innerHTML = schemaTemplates.map((template) => (
						`<option value="${escapeHtml(template.id)}">${escapeHtml(template.name)}</option>`
					)).join('');
					applySchemaTemplate(schemaTemplates[0]);
				};

				const loadSchemaTemplates = async () => {
					const result = await request('/settings/schema-templates');
					schemaTemplates = result.templates || [];
					renderSchemaTemplates();
				};

				root.querySelectorAll('[data-tab]').forEach((button) => {
					button.addEventListener('click', () => {
						root.querySelectorAll('[data-tab]').forEach((item) => item.classList.toggle('is-active', item === button));
						root.querySelectorAll('[data-panel]').forEach((panel) => panel.classList.toggle('is-active', panel.dataset.panel === button.dataset.tab));
						if (button.dataset.tab === 'queue') loadQueue();
						if (button.dataset.tab === 'scraper') loadGeminiKey().catch((error) => toast(error.message));
						if (button.dataset.tab === 'scraper') loadSchemaTemplates().catch((error) => toast(error.message));
					});
				});

				root.querySelector('[data-schema-template-select]').addEventListener('change', (event) => {
					const template = schemaTemplates.find((item) => String(item.id) === String(event.currentTarget.value));
					applySchemaTemplate(template);
				});

				root.querySelector('[data-schema-template-new]').addEventListener('click', () => {
					const form = root.querySelector('[data-scraper-form]');
					form.elements.schema_template_id.value = 'new';
					form.elements.schema_template_name.value = `Mẫu ${schemaTemplates.length + 1}`;
					form.elements.json_schema.value = '{\n  "title": "string",\n  "summary": "string",\n  "review_content": "string"\n}';
					toast('Đang tạo mẫu schema mới.');
				});

				root.querySelector('[data-schema-template-save]').addEventListener('click', async (event) => {
					const form = root.querySelector('[data-scraper-form]');
					let parsed;
					try {
						parsed = JSON.parse(form.elements.json_schema.value);
					} catch (error) {
						toast('JSON schema chua hop le.');
						return;
					}
					if (!parsed.title) {
						toast('Schema cần có field title.');
						return;
					}
					await withBusy(event.currentTarget, 'Saving...', async () => {
						const result = await request('/settings/schema-templates', {
							method: 'PATCH',
							body: JSON.stringify({
								id: form.elements.schema_template_id.value,
								name: form.elements.schema_template_name.value,
								schema: JSON.stringify(parsed, null, 2),
							}),
						});
						schemaTemplates = result.templates || [];
						renderSchemaTemplates();
						applySchemaTemplate(result.template);
						toast('Đã lưu mẫu JSON schema.');
					});
				});

				root.querySelector('[data-gemini-key-toggle]').addEventListener('click', (event) => {
					const input = root.querySelector('[data-gemini-key-input]');
					const isHidden = input.type === 'password';
					input.type = isHidden ? 'text' : 'password';
					event.currentTarget.textContent = isHidden ? 'Hide' : 'Show';
				});

				root.querySelector('[data-gemini-key-form]').addEventListener('submit', async (event) => {
					event.preventDefault();
					const form = event.currentTarget;
					const button = form.querySelector('button[type="submit"]');
					await withBusy(button, 'Saving...', async () => {
						const payload = Object.fromEntries(new FormData(form).entries());
						await request('/settings/gemini-api-key', { method: 'PATCH', body: JSON.stringify(payload) });
						toast('Đã lưu Gemini API key.');
					});
				});

				root.querySelector('[data-product-form]').addEventListener('submit', async (event) => {
					event.preventDefault();
					const form = event.currentTarget;
					const button = form.querySelector('button[type="submit"]');
					await withBusy(button, 'Saving...', async () => {
						const payload = Object.fromEntries(new FormData(form).entries());
						await request('/products', { method: 'POST', body: JSON.stringify(payload) });
						form.reset();
						await loadProducts();
						toast('Đã thêm product.');
					});
				});

				root.querySelector('[data-products-list]').addEventListener('click', async (event) => {
					const button = event.target.closest('[data-delete-product]');
					if (!button) return;
					await withBusy(button, 'Deleting...', async () => {
						await request(`/products/${button.dataset.deleteProduct}`, { method: 'DELETE' });
						await loadProducts();
						await loadQueue();
						toast('Đã xóa product.');
					});
				});

				root.querySelector('[data-transcript-check]').addEventListener('click', async (event) => {
					const form = root.querySelector('[data-scraper-form]');
					const output = root.querySelector('[data-transcript-output]');
					const payload = Object.fromEntries(new FormData(form).entries());
					if (!payload.youtube_url) {
						toast('Nhập YouTube URL trước.');
						return;
					}
					await withBusy(event.currentTarget, 'Checking...', async () => {
						output.value = 'Đang lấy transcript...';
						try {
							const result = await request('/scraper/transcript', { method: 'POST', body: JSON.stringify(payload) });
							output.value = result.transcript || '';
							toast(`Đã lấy transcript (${result.chars || output.value.length} ký tự).`);
						} catch (error) {
							output.value = error.message;
							toast(error.message);
						}
					});
				});

				root.querySelector('[data-official-text-check]').addEventListener('click', async (event) => {
					const form = root.querySelector('[data-scraper-form]');
					const output = root.querySelector('[data-official-text-output]');
					const payload = Object.fromEntries(new FormData(form).entries());
					if (!payload.product_id) {
						toast('Chọn product trước.');
						return;
					}
					await withBusy(event.currentTarget, 'Checking...', async () => {
						output.value = 'Đang extract PDF / official text...';
						try {
							const result = await request('/scraper/official-text', { method: 'POST', body: JSON.stringify(payload) });
							output.value = result.text || '';
							toast(`Đã extract official text (${result.chars || output.value.length} ký tự).`);
						} catch (error) {
							output.value = error.message;
							toast(error.message);
						}
					});
				});

				root.querySelector('[data-scraper-form]').addEventListener('submit', async (event) => {
					event.preventDefault();
					const form = event.currentTarget;
					const button = form.querySelector('button[type="submit"]');
					await withBusy(button, 'Running...', async () => {
						const payload = Object.fromEntries(new FormData(form).entries());
						await request('/scraper/run', { method: 'POST', body: JSON.stringify(payload) });
						form.reset();
						await loadQueue();
						await loadSchemaTemplates();
						toast('Đã tạo bản tóm tắt/review và đưa vào Content Queue.');
					});
				});

				root.querySelector('[data-queue-list]').addEventListener('click', (event) => {
					const button = event.target.closest('[data-open-post]');
					if (!button) return;
					const item = pendingPosts.find((post) => String(post.id) === String(button.dataset.openPost));
					if (!item) return;
					const form = root.querySelector('[data-editor-form]');
					form.elements.id.value = item.id;
					form.elements.title.value = item.content_json?.title || '';
					form.elements.summary.value = item.content_json?.summary || '';
					form.elements.body.value = item.content_json?.review_content || item.content_json?.body || '';
					form.elements.destination.value = item.content_json?.finished_destination || 'post';
				});

				root.querySelector('[data-editor-form]').addEventListener('submit', async (event) => {
					event.preventDefault();
					const form = event.currentTarget;
					const id = form.elements.id.value;
					if (!id) {
						toast('Hãy chọn một post pending trước.');
						return;
					}
					const button = form.querySelector('button[type="submit"]');
					await withBusy(button, 'Finishing...', async () => {
						const item = pendingPosts.find((post) => String(post.id) === String(id));
						const result = await request(`/posts-queue/${id}/finish`, {
							method: 'POST',
							body: JSON.stringify({
								destination: form.elements.destination.value,
								content_json: {
									...(item?.content_json || {}),
									title: form.elements.title.value,
									summary: form.elements.summary.value,
									review_content: form.elements.body.value,
								},
							}),
						});
						form.reset();
						await loadQueue();
						toast(`Đã tạo bài pending #${result.post_id} trong ${result.post_type}.`);
					});
				});

				Promise.all([loadProducts(), loadQueue(), loadGeminiKey(), loadSchemaTemplates()]).catch((error) => toast(error.message));
			})();
			</script>
			<?php
		}
	}
}

if ( ! class_exists( 'Zenclau_V1_Content_System' ) ) {
	/**
	 * Loader for Youtube Content System.
	 */
	final class Zenclau_V1_Content_System {
		/**
		 * Boot hooks.
		 *
		 * @return void
		 */
		public static function init() {
			add_action( 'init', array( 'Zenclau_V1_Content_Model', 'maybe_install_tables' ), 5 );
			Zenclau_V1_REST_API::init();
			Zenclau_V1_Admin_UI::init();
		}
	}
}
